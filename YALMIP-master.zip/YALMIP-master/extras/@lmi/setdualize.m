function sys = setdualize(sys,state)

sys.dualized = state;